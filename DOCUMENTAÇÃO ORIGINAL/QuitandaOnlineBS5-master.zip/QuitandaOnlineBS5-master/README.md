# Loja Virtual "Quitanda Online" com Bootstrap 5

Esse é o código-fonte do design da loja virtual "Quitanda Online" cujo vídeo mostrando o passo-a-passo de construção está disponível no YouTube, no link https://youtu.be/0fUB_f_XKsM . 

Se você tiver alguma contribuição a fazer, sinta-se a vontade para sugerir. Se for pertinente, implementarei e darei os créditos a você.

Espero que esse projeto seja realmente útil pra você.

Um grande abraço!
